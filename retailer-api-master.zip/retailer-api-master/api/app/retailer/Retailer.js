let RetailerModel = require('./RetailerModel');
let env = process.env.NODE_ENV || 'development';
let conf = require('../../lib/config');
let apiUrl = conf[env].apiUrl;
let moment = require('moment');
let randomize = require('randomatic');
let fs = require('fs');
let randToken = require('rand-token');
let _ = require('lodash');
let asynchronous = require('async');
const upload = require('../../lib/fileupload');
const uploadImg = upload.single('image');
class Retailer extends RetailerModel {
   constructor(){
       super();
   }
   create(user){
       return new Promise((resolve, reject) => {
            if(!user.contact_number) reject(onf.error.message.mobilenoErr);

           else if(!user.user_name) reject(conf.error.message.usernameErr);

           else if(!user.password) reject(conf.error.message.passwordErr);

           else if(!user.email) reject(conf.error.message.emailErr);

           else if(!user.role_name) reject(conf.error.message.usernameErr);

           else {
               user.password = this.encryptpassword(user.password);
               // user.role_name = (user.role_name && user.role_name == "admin")?"admin":"retailer";
               this.setTable('retailer_master');
               this.getRetailer(user)
               .then((retailer) => {
                   if(retailer.length > 0){
                       reject(conf.error.message.userExist);
                   }else {
                       user.created_at = moment().format("YYYY-MM-DD HH:mm:ss");
                       user.updated_at = moment().format('YYYY-MM-DD HH:mm:ss');
                       this._insertRetailer(user)
                       .then((user_details) => {
                           resolve(user_details);
                       });
                   }

               })

           }

       });
   }
   login({ user_name, password}){
       return new Promise((resolve, reject) => {
           if(!user_name) reject (new Error(conf.error.message.usernameErr));

           else if(!password) reject (new Error(conf.error.message.passwordErr));
           else {
               this.setTable('retailer_master');
               this.getRetailerByUsername(user_name)
               .then((result) => {
                   if(result.length > 0){
                        if(result[0].active == 'Y'){
                               let pass = this.decryptPass(result[0].password);
                               if(password != pass)
                                  reject(new Error("Password is incorrect"));
                               else{
                                   let token = this.generateJWT(result[0]);
                                   resolve(token);
                               }
                       } else reject(new Error("Your account has been blocked. Please contact admin."));
                   }
                   else reject(new Error(conf.error.message.getUserErr));
               })
               .catch((err) => {
                   reject(err);
               })
           }
       });
   }
   getSizes(user_id = 0) {
       return new Promise((resolve, reject) => {
           if(user_id){
               this.getRetailerSizes(user_id)
                   .then((val) =>{
                       resolve(val)
                   })
                   .catch((err) => reject(err));
           } else reject(new Error( conf.error.message.invalidParam ));
       });
   }
   getRetailers(name = new String()) {
       return new Promise((resolve, reject) => {
           if(name){
               this._getRetailers(name)
                   .then((val) =>{
                       resolve(val)
                   })
                   .catch((err) => reject(err));
           } else reject(new Error( conf.error.message.invalidParam ));
       });
   }
   getAllRetailers() {
       return new Promise((resolve, reject) => {
         this._getAllRetailers()
         .then((val) =>{
             resolve(val)
         })
         .catch((err) => reject(err));
       });
   }
   getCategories(user_id = 0) {
       return new Promise((resolve, reject) => {
           if(user_id){
               this.getRetailerCategories(user_id)
                   .then((val) =>{
                       resolve(val)
                   })
                   .catch((err) => reject(err));
           } else reject(new Error( conf.error.message.invalidParam ));
       });
   }
   getColors(user_id = 0) {
       return new Promise((resolve, reject) => {
           if(user_id){
               this.getRetailerColors(user_id)
                   .then((val) =>{
                       resolve(val)
                   })
                   .catch((err) => reject(err));
           } else reject(new Error( conf.error.message.invalidParam ));
       });
   }
   addColor(color_name = new String()) {
       return new Promise((resolve, reject) => {
           if(color_name != ''){
               this.select(`select * from other_products_colours where color_name like '%${color_name}%'`,null)
               .then((color) => {
                   if(color.length == 0){
                       this.setTable('other_products_colours');
                       this._addColor(color_name)
                       .then((val) =>{
                           resolve(val)
                       })
                       .catch((err) => reject(err));
                   }else reject('Color name already exists');
               });
           } else reject(conf.error.message.colorName);
       });
   }

   changePassword(retailer = new Object()){
       const { id, password, confirm_password } = retailer;
       return new Promise((resolve, reject) => {
           if(!password) reject(conf.error.message.passwordErr);
           else if(!confirm_password) reject(conf.error.message.confirmPassErr);
           else if(password != confirm_password) reject(conf.error.message.passMatchErr);
           else {
               this.setTable('retailer_master');
               this.getRetailerById(id)
               .then((result) => {
                   if(result.length == 0){
                       reject(conf.error.message.getUserErr);
                   }else {
                       let encpassword = this.encryptpassword(password);
                       return this.updatePassword(encpassword,id);
                   }
               })
               .then((update)=>{
                   resolve(update);
               });
           }
       });
   }
   addProduct(fk_retailer_id = new Number(),product = new Object()){
     const { product_name, description,
            specification, product_code,
            fk_category_id,
            actual_price,
            discounted_price,
            image,
            product_combinations,
            product_weight } = product;
    const is_active = 'Y';
     return new Promise((resolve, reject) => {
         if(!product_name) reject(conf.error.message.emptyField('Product name'));
         else if(!description) reject(conf.error.message.emptyField('Product description'));
         else if(!product_code) reject(conf.error.message.emptyField('Product product code'));
         else if(!specification) reject(conf.error.message.emptyField('Product specification'));
         else if(!product_weight) reject(conf.error.message.emptyField('Product weight'));
         else if(!fk_category_id) reject(conf.error.message.emptyField('Product category'));
         else if(!fk_retailer_id) reject(conf.error.message.emptyField('Retailer id'));
         else if(!actual_price) reject(conf.error.message.emptyField('Product price'));
         else if(!discounted_price) reject(conf.error.message.emptyField('Product discount'));
         else if(!product_combinations) reject(conf.error.message.emptyField('Product combinations'));
         else if(!image) reject(conf.error.message.emptyField('Product image'));
         else {
            let insertProduct = {
                fk_retailer_id,
                is_active,
                product_name,
                description,
                specification,
                product_code,
                fk_category_id,
                product_weight,
                actual_price,
                discounted_price,
                image
           }
           insertProduct.DtCreated = moment().format("YYYY-MM-DD HH:mm:ss");
           insertProduct.DtModified = insertProduct.DtCreated;
             this.insert('other_products_master',insertProduct)
             .then((result) => {
               return result.insertId;
             })
             .then((product_id) =>{
                let combinations = [];
                 product_combinations.forEach((item,index) => {
                    let combination = new Array();
                    combination.push(item.color);
                    combination.push(item.size);
                    combination.push((index == 0)?'Y':'N');
                    combination.push(product_id);
                    combination.push(item.count);
                    combination.push('Y');
                    combinations.push(combination);
                 });
                 return this.insertOtherCombinations(combinations);
             })
             .then((result) =>{
                resolve(result);
             }).catch((err) => {
                 reject(err);
             })
         }
     });
   }
   getProducts(fk_retailer_id = new Number(),limit = new Number(),offset = new Number()){
     return new Promise((resolve, reject) => {
         if(!limit) reject(conf.error.message.emptyField('Product limit'));
         else if(typeof offset === "undefined") reject(conf.error.message.emptyField('Product offset'));
         else{
           // const is_active = 'Y';
            // let fields = { fk_retailer_id,is_active };
            this._getProducts(fk_retailer_id,offset,limit)
            .then((result) => {
              const products = [];
              const total = 0;
              const data = {
                  products,
                  total
              }
              result.forEach((product,index) => {
                if(index == 0)
                  data.total = product.total;
                const { product_name, id,
                        fk_retailer_id,
                         actual_price,
                         discounted_price,
                         image,
                         is_active} = product;
                    data.products.push({
                       product_name,
                       id,
                       fk_retailer_id,
                       actual_price,
                       discounted_price,
                       image,
                       is_active
                    })
              });
              resolve(data);
            }).catch((err) => {
              // let error = {
              //    api_name: 'get',
              //    datetime_created:moment().format('YYYY-MM-DD HH:mm:ss'),
              //    user_id:user_id,
              //    error_message:err
              //  };
              //  this._addToErrorLog(error);
                reject(err);
            })
         }
       });
   }
   getProductById(fk_retailer_id = new Number(),id = new Number()){
       return new Promise((resolve, reject) => {
           return this._getProductById(fk_retailer_id,id)
           .then((result) => {
             let product = {};
             result.forEach(function(item,index){
               if(index == 0){
                 product.product_name = item.product_name;
                 product.description = item.description;
                 product.specification = item.specification;
                 product.image = item.image;
                 product.fk_retailer_id = item.fk_retailer_id;
                 product.product_id = item.id;
                 product.actual_price = item.actual_price;
                 product.product_weight = item.product_weight;
                 product.discounted_price = item.discounted_price;
                 product.product_code = item.product_code;
                 product.category_name = item.category_name;
                 product.category_id = item.fk_category_id;
                 product.is_active = (item.is_active == "Y")?'Active':'In active';
                 product.total = 0;
                 product.combinations = [];
               }
               product.combinations.push({
                 color_id:item.other_products_color_id,
                 size_id:item.other_products_size_id,
                 color_name:item.color_name,

                 count:item.count,
                 size_name:item.size_name
               });
               product.total += item.count;
             });
             resolve(product);
           })
           .catch((err) => { reject(err) });
       });
   }

   createPassword(id = new Number(),password = new String()){
       return new Promise((resolve, reject) => {
            let encpassword = this.encryptpassword(password);
           return this._createPassword(id,encpassword)
           .then((result) => {
             resolve(result);
           })
           .catch((err) => reject(err));
       });
   }
 }
module.exports = Retailer;
