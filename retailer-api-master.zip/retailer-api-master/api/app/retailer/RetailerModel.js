let Helper = require('../../lib/Helper');
let config = require('../../lib/config');
let moment = require('moment');

class RetailerModel extends Helper {
  constructor(){
      super();
      this.table = 'retailer_master';
  }
  setTable(table){
      this.table = table;
  }
  _insertRetailer(user){
      return new Promise((resolve, reject) => {
          this.insert(this.table, user)
          .then((result) => {
              if(result.affectedRows){
                  resolve(result.insertId);
              } else reject(new Error(config.error.message.dbError));
          }).catch((err) => {
              reject(err);
          });
      });
  }
  getRetailerByUsername(user_name = new String()){
      return new Promise((resolve, reject) => {
          this.get(this.table, { user_name })
          .then((result) => {
              resolve(result);
          }).catch((err)=>{
              reject(err);
          });
      });
  }
  getRetailerById(id = new Number()){
      return new Promise((resolve, reject) => {
          // `select select`
          this.get(this.table, { id })
          .then((result) => {
              resolve(result);
          }).catch((err)=>{
              reject(err);
          });
      });
  }
  _getProducts(fk_retailer_id = new Number(),offset = new Number(),limit = new Number()){
    return new Promise((resolve, reject) => {
        let sql = `select
        other_products_master.id,
    	  product_name,
    	  fk_retailer_id,
    	  image,
    	  discounted_price,
    	  actual_price,
    	  is_active,
    (select count(*) from other_products_master where fk_retailer_id = ${fk_retailer_id}) as total
      from other_products_master where fk_retailer_id = ${fk_retailer_id} ORDER BY id DESC limit ${offset},${limit}`;
          this.select(sql, null)
          .then((result) => {
              resolve(result);
          }).catch((err)=>{
              reject(err);
          });
    });

  }
  updateRetailer(id = new Number(),retailer = new Object()){
      return new Promise((resolve, reject) => {
          let sql = `UPDATE retailer_master
                      SET name = '${retailer.name}',
                      contact_number = '${retailer.contact_number}',
                      email = '${retailer.email}',
                      address = '${retailer.address}',
                      contact_number = ${retailer.contact_number}
                      WHERE id = ${id}`;
          this.select(sql, null)
          .then((result) => {
              resolve(result);
          }).catch((err)=>{
              reject(err);
          });
      });
  }
  getRetailer(cond = new Object()){
    return new Promise((resolve, reject) => {
        let sql = `select * from ${this.table} where
                contact_number = ${cond.contact_number} or user_name = '${cond.user_name}'
                or email = '${cond.email}'`;
        console.log(sql)
        this.select(sql,null)
        .then((result) => {
            resolve(result);
        }).catch((err) => {
            reject(err);
        });
    });
  }
  updatePassword(password = new String(), id = new Number()){
    return new Promise((resolve, reject) => {
      this.table = 'retailer_master';
        this.update(this.table, { password }, { id })
        .then((result) => {
            if(result.affectedRows){
                resolve(result);
            } else reject(new Error(config.error.message.dbError));
        })
        .catch((err) => {
            reject(err);
        })
    });
  }
  getRetailerSizes(user_id = 0){
      return new Promise((resolve, reject) => {
          let sql = `SELECT id,size_name from other_products_sizes where active = 'Y'`;
          this.select(sql, null)
          .then((result) => {
            resolve(result)
          })
          .catch((err) => reject(err));
      });
  }
  getRetailerCategories(user_id = 0){
      return new Promise((resolve, reject) => {
          let sql = `SELECT id,category_name from category_master where active = 'Y'`;
          this.select(sql, null)
          .then((result) => {
            resolve(result)
          })
          .catch((err) => reject(err));
      });
  }
  getRetailerColors(user_id = 0){
      return new Promise((resolve, reject) => {
          let sql = `SELECT id,color_name
          from other_products_colours where active = 'Y'`;
          this.select(sql, null)
          .then((result) => {
            resolve(result)
          })
          .catch((err) => reject(err));
      });
  }
  _addColor(color_name = new String()){
      return new Promise((resolve, reject) => {
          const active = "Y";
          const params = {
            color_name,
            active
          };
          this.insert(this.table,params)
          .then((result) => {
              if(result.affectedRows){
                  resolve(result.insertId);
              } else reject(config.error.message.dbError);
          })
          .catch((err) => reject(err));
      });
  }

  _getProductById(fk_retailer_id = new Number(),id = new Number()){
      return new Promise((resolve, reject) => {
        let sql = `SELECT
            other_products_master.id,
            other_products_master.product_name,
            other_products_master.description,
            other_products_master.specification,
            other_products_master.fk_retailer_id,
            other_products_master.is_active,
            other_products_master.actual_price,
            other_products_master.product_weight,
            other_products_master.discounted_price,
            other_products_master.product_code,
            other_products_combinations.other_products_color_id,
            other_products_master.fk_category_id,
            other_products_combinations.count,
            (SELECT category_name FROM category_master
            WHERE id = other_products_master.fk_category_id) category_name,
            (SELECT color_name FROM other_products_colours
            WHERE id = other_products_combinations.other_products_color_id) color_name,
            other_products_combinations.other_products_size_id,
            (SELECT size_name FROM other_products_sizes WHERE id = other_products_combinations.other_products_size_id) size_name,
            other_products_master.image
            FROM other_products_combinations
            INNER JOIN other_products_master
            ON other_products_combinations.other_products_id = other_products_master.id
            WHERE other_products_combinations.other_products_id = ${id}
            AND other_products_master.fk_retailer_id = ${fk_retailer_id}
            AND other_products_combinations.active = 'Y'`;
          // let fields = {fk_retailer_id,id};
          this.select(sql, null)
          .then((result) => {
              resolve(result);
          }).catch((err)=>{
              reject(err);
          });
      });
  }
  _createPassword(id = new Number(),password = new String()){
    return new Promise((resolve, reject) => {
        this.update(this.table, { password }, { id })
        .then((result) => {
            if(result.affectedRows){
                resolve(result);
            } else reject(new Error(config.error.message.dbError));
        })
        .catch((err) => {
            reject(err);
        })
    });
  }
  _getRetailers(name = new String()){
      return new Promise((resolve, reject) => {
          let sql = `SELECT rm.id,rm.name,rm.user_name,rm.contact_number,rm.email
           from retailer_master as rm where name like '%${name}%' and active = 'Y' and role_name = 'retailer' limit 0,5`
          this.select(sql, null)
          .then((result) => {
              resolve(result);
          }).catch((err)=>{
              reject(err);
          });
      });
  }
  _getAllRetailers(){
    return new Promise((resolve, reject) => {
        let sql = `SELECT rm.id,rm.name,rm.user_name,rm.contact_number,rm.email
         from retailer_master as rm where active = 'Y' and password IS NULL OR user_name IS NULL`
        this.select(sql, null)
        .then((result) => {
            resolve(result);
        }).catch((err)=>{
            reject(err);
        });
    });
  }
}

module.exports = RetailerModel;
