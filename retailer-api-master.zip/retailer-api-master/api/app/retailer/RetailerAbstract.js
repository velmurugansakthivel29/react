let Retailer = require('./Retailer');
let env = process.env.NODE_ENV || 'development';
let conf = require('../../lib/config');
let webURL = conf[env].webURL;
var request = require('request');
let moment = require('moment');
let retailer = new Retailer();
const upload = require('../../lib/fileupload');
const uploadImg = upload.single('file');
class RetailerAbstract{
    constructor() {  }
    static create(req, res, next) {
        retailer.create(req.body)
        .then((user) => {
            if(user){
                res.status(200).json({"status": "success", message: conf.success.message.retailerSuccess });
            }else{
                res.status(300).json({"status": "fail", error: conf.error.message.networkError });
            }
        })
        .catch((err) => {
            res.status(300).json({"status": "fail", error: err.toString()});
        })
    }
    static login(req, res, next) {
        retailer.login(req.body)
        .then((token) => {
            if(token){
                res.setHeader("AuthToken",token);
                res.status(200).json({"status": "success", message: conf.success.message.auth });
            }else{
                res.status(300).json({"status": "fail", error: conf.error.message.networkError });
            }
        })
        .catch((err) => {
            res.status(300).json({"status": "fail", error: err.toString()});
        });
    }
    static changePassword(req, res, next) {
      let authtoken = req.headers['authtoken'];
      retailer.validateToken(authtoken)
        .then((decoded) => {
            if(typeof(decoded) == 'object' && decoded.hasOwnProperty('newToken')){
                res.setHeader("authtoken", decoded.newToken);
            }
            const obj = {
                id:decoded.id,
                password:req.body.password,
                confirm_password:req.body.confirm_password
            };
            return retailer.changePassword(obj);
        })
        .then((response) => {
            res.status(200).json({"status": "success", "message": conf.success.message.passwordSuccess});
        })
        .catch((err) => {
            res.status(300).json({"status": "fail", error: err.toString()});
        });
    }
    static getRetailerInfo(req, res, next) {
      let authtoken = req.headers['authtoken'];
      retailer.validateToken(authtoken)
        .then((decoded) => {
            if(typeof(decoded) == 'object' && decoded.hasOwnProperty('newToken')){
                res.setHeader("authtoken", decoded.newToken);
            }
            return retailer.getRetailerById(decoded.id);
        })
        .then((response) => {
            response[0].password = undefined;
            response[0].active = undefined;
            response[0].id = undefined;
            res.status(200).json({"status": "success", "result": response[0]});
        })
        .catch((err) => {
            res.status(300).json({"status": "fail", error: err.toString()});
        });
    }
    static updateRetailer(req, res, next) {
      let authtoken = req.headers['authtoken'];
      retailer.validateToken(authtoken)
        .then((decoded) => {
            if(typeof(decoded) == 'object' && decoded.hasOwnProperty('newToken')){
                res.setHeader("authtoken", decoded.newToken);
            }
            return retailer.updateRetailer(decoded.id,req.body);
        })
        .then((response) => {
            res.status(200).json({"status": "success", "result": "Your details updated successfully"});
        })
        .catch((err) => {
            res.status(300).json({"status": "fail", error: err.toString()});
        });
    }
    static addProduct(req, res, next) {
      let authtoken = req.headers['authtoken'];
      retailer.validateToken(authtoken)
        .then((decoded) => {
            if(typeof(decoded) == 'object' && decoded.hasOwnProperty('newToken')){
                res.setHeader("authtoken", decoded.newToken);
            }
            return retailer.addProduct(decoded.id,req.body);
        })
        .then((response) => {
            res.status(200).json({"status": "success", "message": conf.success.message.prouctAdded});
        })
        .catch((err) => {
            res.status(300).json({"status": "fail", error: err.toString()});
        });
    }
    static getSizes(req, res, next) {
        let token = req.headers['authtoken'];
        retailer.validateToken(token)
          .then((decoded) => {
              if(typeof(decoded) == 'object' && decoded.hasOwnProperty('newToken')){
                  res.setHeader("AuthToken", decoded.newToken);
              }
              return retailer.getSizes(decoded.id);
          })
          .then((value) => {
              res.status(200).json({"status": "success", result: value});
          })
          .catch((err) => {
              res.status(300).json({"status": "fail", error: err.toString()});
          });
    }
    static getCategories(req, res, next) {
        let token = req.headers['authtoken'];
        retailer.validateToken(token)
          .then((decoded) => {
              if(typeof(decoded) == 'object' && decoded.hasOwnProperty('newToken')){
                  res.setHeader("AuthToken", decoded.newToken);
              }
              return retailer.getCategories(decoded.id);
          })
          .then((value) => {
              res.status(200).json({"status": "success", result: value});
          })
          .catch((err) => {
              res.status(300).json({"status": "fail", error: err.toString()});
          });
    }
    static getColors(req, res, next) {
        let token = req.headers['authtoken'];
        retailer.validateToken(token)
          .then((decoded) => {
              if(typeof(decoded) == 'object' && decoded.hasOwnProperty('newToken')){
                  res.setHeader("AuthToken", decoded.newToken);
              }
              return retailer.getColors(decoded.id);
          })
          .then((value) => {
              res.status(200).json({"status": "success", result: value});
          })
          .catch((err) => {
              res.status(300).json({"status": "fail", error: err.toString()});
          });
    }
    static addColor(req, res, next) {
        let token = req.headers['authtoken'];
        retailer.validateToken(token)
          .then((decoded) => {
              if(typeof(decoded) == 'object' && decoded.hasOwnProperty('newToken')){
                  res.setHeader("AuthToken", decoded.newToken);
              }
              return retailer.addColor(req.body.color_name);
          })
          .then((id) => {
              const color_name = req.body.color_name;
              const result = {
                id,
                color_name
              };
              res.status(200).json({"status": "success",result});
          })
          .catch((err) => {
              res.status(300).json({"status": "fail", error: err.toString()});
          });
    }

    static imageUpload(req, res, next) {
      uploadImg(req,res,function(err){
        const img_name = req.file.location.split('/')[4];
        res.status(200).json({"status": "success", "result": img_name});
      });
    }
    static getRetailerProduct(req, res, next) {
      let token = req.headers['authtoken'];
      retailer.validateToken(token)
        .then((decoded) => {
            if(typeof(decoded) == 'object' && decoded.hasOwnProperty('newToken')){
                res.setHeader("AuthToken", decoded.newToken);
            }
            return retailer.getProducts(decoded.id,req.body.limit,req.body.offset);
        })
        .then((value) => {
            res.status(200).json({"status": "success", products: value.products,total: value.total});
        })
        .catch((err) => {
            res.status(300).json({"status": "fail", error: err.toString()});
        });
    }
    static getRetailerProductById(req, res, next) {
      let token = req.headers['authtoken'];
      retailer.validateToken(token)
        .then((decoded) => {
            if(typeof(decoded) == 'object' && decoded.hasOwnProperty('newToken')){
                res.setHeader("AuthToken", decoded.newToken);
            }
            return retailer.getProductById(decoded.id,req.params.id);
        })
        .then((value) => {
            res.status(200).json({"status": "success", result: value});
        })
        .catch((err) => {
            res.status(300).json({"status": "fail", error: err.toString()});
        });
    }

    static retailerResetPassword(req, res, next){
      let token = req.headers['authtoken'];
      retailer.validateToken(token)
        .then((decoded) => {
            if(typeof(decoded) == 'object' && decoded.hasOwnProperty('newToken')){
                res.setHeader("AuthToken", decoded.newToken);
            }
            retailer.createPassword(req.body.retailer_id,req.body.password);
        })
        .then((value) => {
            res.status(200).json({"status": "success", result: value});
        })
        .catch((err) => {
            res.status(300).json({"status": "fail", error: err.toString()});
        });
    }
    static getRetailers(req, res, next) {
        let token = req.headers['authtoken'];
        retailer.validateToken(token)
          .then((decoded) => {
              if(typeof(decoded) == 'object' && decoded.hasOwnProperty('newToken')){
                  res.setHeader("AuthToken", decoded.newToken);
              }
              return retailer.getRetailers(req.body.name);
          })
          .then((value) => {
              res.status(200).json({"status": "success", result: value});
          })
          .catch((err) => {
              res.status(300).json({"status": "fail", error: err.toString()});
          });
    }
    static getAllRetailers(req, res, next) {
        let token = req.headers['authtoken'];
        retailer.validateToken(token)
          .then((decoded) => {
              if(typeof(decoded) == 'object' && decoded.hasOwnProperty('newToken')){
                  res.setHeader("AuthToken", decoded.newToken);
              }
              return retailer.getAllRetailers();
          })
          .then((value) => {
              res.status(200).json({"status": "success", result: value});
          })
          .catch((err) => {
              res.status(300).json({"status": "fail", error: err.toString()});
          });
    }
}
module.exports = RetailerAbstract;
