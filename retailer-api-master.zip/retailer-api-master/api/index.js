var express = require('express');
var router = express.Router();
var FCM = require('fcm-push');
// var fcm = new FCM('AIzaSyA5hw5zU5y13aL6RR1wt7lO5tyJoXTGChA');
// var fcm = new FCM('AIzaSyC7WiI-iXx7bD2QGGyAuGN_m0uenIsadM4');
//var fcm = new FCM('AIzaSyBGDP-QMTr0H2rvwjfzlqvY6U8B6Rla_G0');
var fcm = new FCM('AIzaSyCobIW0VWeG0eUbEgKz3rkjYs7WXcWVvNQ');

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: `USEE API Running On Port ${process.env.PORT}` });
});

router.post('/test_fcm_push', function(req, res, next){
  var message = {
      to: 'cx94Sf0HksE:APA91bF7riX-iV3lWSM8nYFII-KtxPIJR9sG8339mgO51VKHiKyDqtnFIhn9cHXsjKmWQpi2Ktou3dwvBn81ldiEqg2rAxKIZIywVkbn6Lab2lzTuGi1UMgrdbRplCnsquTbta0rTPhx',
      collapse_key: 'newage',
      data: {
          first_name: 'Jibin Joy',
          channelId: "123456"
      },
      notification: {
          title: 'Hello World',
          body: 'USee test push notification',
          sound: 'default'
      }
  };
  fcm.send(message)
    .then(function(response){
      res.json({"status": true, message: `Successfully sent with response: ${response}`});
    })
    .catch(function(err){
      res.json({"status": false, error: `Something has gone wrong!: ${err}`});
    });
});
module.exports = router;
