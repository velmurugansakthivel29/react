export const CREATE_USER = "CREATE_USER";
export const LOGIN_USER = "LOGIN_USER";
export const GET_USER = "GET_USER";
export const SET_USER_DETAILS = "SET_USER_DETAILS";
