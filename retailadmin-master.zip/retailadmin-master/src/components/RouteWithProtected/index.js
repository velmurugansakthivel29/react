export { default } from './RouteWithProtected';
