export { default } from './ViewProduct';
