export { default } from './Retailer';
